const filterDateButton = document.getElementById('filter-date');
const datePicker = document.getElementById('date-picker');
const dateInput = document.getElementById('date-input');
const applyDateButton = document.getElementById('apply-date');
const selectedDate = document.getElementById('selected-date');

const filterTypeButton = document.getElementById('filter-type');
const dropdownType = document.getElementById('dropdown-type');
const orderTypeSelect = document.getElementById('order-type-select');
const applyTypeButton = document.getElementById('apply-type');
const selectedType = document.getElementById('selected-type');

const filterStatusButton = document.getElementById('filter-status'); // Added filter for status
const resetFilters = document.getElementById('reset-filters');

// Event listener for the "Filter by Date" button
filterDateButton.addEventListener('click', () => {
  alert('Filter by date functionality coming soon!');
});

// Event listener for the "Filter by Status" button
filterStatusButton.addEventListener('click', () => {
  alert('Filter by status functionality coming soon!');
});

// Toggle Date Picker
filterDateButton.addEventListener('click', () => {
  datePicker.style.display = datePicker.style.display === 'block' ? 'none' : 'block';
});

// Apply Date
applyDateButton.addEventListener('click', () => {
  const date = dateInput.value;
  if (date) {
    selectedDate.textContent = new Date(date).toLocaleDateString();
    datePicker.style.display = 'none';
  }
});

// Toggle Dropdown for Order Type
filterTypeButton.addEventListener('click', () => {
  dropdownType.style.display = dropdownType.style.display === 'block' ? 'none' : 'block';
});

// Apply Order Type
applyTypeButton.addEventListener('click', () => {
  const type = orderTypeSelect.value;
  if (type) {
    selectedType.textContent = type;
    dropdownType.style.display = 'none';
  }
});

// Reset Filters
resetFilters.addEventListener('click', () => {
  selectedDate.textContent = 'Select Date';
  dateInput.value = '';
  selectedType.textContent = 'Select Type';
  orderTypeSelect.value = '';
});

document.addEventListener("DOMContentLoaded", () => {
  const logoutLink = document.getElementById("logout-link");
  const confirmPopup = document.getElementById("confirm-popup");
  const confirmLogout = document.getElementById("confirm-logout");
  const cancelLogout = document.getElementById("cancel-logout");

  // เมื่อคลิกที่ปุ่ม Logout ให้แสดง Popup
  logoutLink.addEventListener("click", (e) => {
    e.preventDefault(); // ป้องกันการกระทำเริ่มต้นของลิงก์
    confirmPopup.classList.remove("hidden"); // แสดง Popup
  });

  // เมื่อกดยืนยัน Logout ให้เปลี่ยนหน้าไปที่ login.html
  confirmLogout.addEventListener("click", () => {
    window.location.href = "register.html"; // ไปยังไฟล์ login.html
  });

  // เมื่อกดยกเลิก Popup ให้ซ่อน Popup
  cancelLogout.addEventListener("click", () => {
    confirmPopup.classList.add("hidden"); // ซ่อน Popup
  });
});