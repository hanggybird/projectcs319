// Sample data for the chart (Sales over last 6 months)
const salesData = {
  labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
  datasets: [{
    label: 'Sales in $',
    data: [1200, 1500, 1100, 1800, 1600, 2000],
    backgroundColor: 'rgba(26, 188, 156, 0.2)',
    borderColor: 'rgba(26, 188, 156, 1)',
    borderWidth: 1,
  }]
};

const config = {
  type: 'bar',
  data: salesData,
  options: {
    responsive: true,
    scales: {
      y: {
        beginAtZero: true,
      }
    }
  }
};

// Rendering the chart
const salesChart = new Chart(
  document.getElementById('salesChart'),
  config
);

document.addEventListener("DOMContentLoaded", () => {
  const logoutLink = document.getElementById("logout-link");
  const confirmPopup = document.getElementById("confirm-popup");
  const confirmLogout = document.getElementById("confirm-logout");
  const cancelLogout = document.getElementById("cancel-logout");

  // เมื่อคลิกที่ปุ่ม Logout ให้แสดง Popup
  logoutLink.addEventListener("click", (e) => {
    e.preventDefault(); // ป้องกันการกระทำเริ่มต้นของลิงก์
    confirmPopup.classList.remove("hidden"); // แสดง Popup
  });

  // เมื่อกดยืนยัน Logout ให้เปลี่ยนหน้าไปที่ login.html
  confirmLogout.addEventListener("click", () => {
    window.location.href = "register.html"; // ไปยังไฟล์ login.html
  });

  // เมื่อกดยกเลิก Popup ให้ซ่อน Popup
  cancelLogout.addEventListener("click", () => {
    confirmPopup.classList.add("hidden"); // ซ่อน Popup
  });
});

