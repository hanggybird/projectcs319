document.addEventListener('DOMContentLoaded', function () {
  const addProductForm = document.getElementById('add-product-form');
  const productTableBody = document.querySelector('#product-table tbody');
  const logoutLink = document.getElementById('logout-link');
  const confirmPopup = document.getElementById('confirm-popup');
  const confirmLogoutButton = document.getElementById('confirm-logout');
  const cancelLogoutButton = document.getElementById('cancel-logout');
  const editPopup = document.getElementById('edit-popup');
  const closeEditPopupButton = document.getElementById('close-edit-popup');
  const editProductForm = document.getElementById('edit-product-form');
  
  let products = [];
  let editingProductIndex = null;

  function displayProducts(products) {
    productTableBody.innerHTML = '';
    products.forEach((product, index) => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td><img src="${product.image}" alt="${product.name}" width="50" height="50"></td>
        <td>${product.name}</td>
        <td>${product.price}</td>
        <td>${product.quantity}</td>
        <td>${product.colors.join(', ')}</td>
        <td class="actions">
          <button class="edit" onclick="editProduct(${index})"><i class="fas fa-edit"></i> Edit</button>
          <button class="delete" onclick="confirmDelete(${index})"><i class="fas fa-trash-alt"></i> Delete</button>
        </td>
      `;
      productTableBody.appendChild(row);
    });
  }

  function openEditPopup(product) {
    document.getElementById('edit-product-name').value = product.name;
    document.getElementById('edit-product-price').value = product.price;
    document.getElementById('edit-product-quantity').value = product.quantity;
    document.getElementById('edit-product-colors').value = product.colors.join(', ');
    editingProductIndex = products.indexOf(product);
    editPopup.classList.remove('hidden');
  }

  function closeEditPopup() {
    editPopup.classList.add('hidden');
  }

  editProductForm.addEventListener('submit', function (e) {
    e.preventDefault();
    
    const productName = document.getElementById('edit-product-name').value;
    const productImage = document.getElementById('edit-product-image').files[0];
    const productPrice = document.getElementById('edit-product-price').value;
    const productQuantity = document.getElementById('edit-product-quantity').value;
    const productColors = document.getElementById('edit-product-colors').value.split(',').map(color => color.trim());

    const reader = new FileReader();
    reader.onload = function () {
      const updatedProduct = {
        name: productName,
        image: reader.result,
        price: productPrice,
        quantity: productQuantity,
        colors: productColors,
      };

      products[editingProductIndex] = updatedProduct;
      displayProducts(products);
      closeEditPopup();
    };
    reader.readAsDataURL(productImage);
  });

  closeEditPopupButton.addEventListener('click', closeEditPopup);

  window.editProduct = function(index) {
    openEditPopup(products[index]);
  };

  window.confirmDelete = function(index) {
    if (confirm('Are you sure you want to delete this product?')) {
      products.splice(index, 1);
      displayProducts(products);
    }
  };

  addProductForm.addEventListener('submit', function (e) {
    e.preventDefault();
    
    const productName = document.getElementById('product-name').value;
    const productImage = document.getElementById('product-image').files[0];
    const productPrice = document.getElementById('product-price').value;
    const productQuantity = document.getElementById('product-quantity').value;
    const productColors = document.getElementById('product-colors').value.split(',').map(color => color.trim());

    const reader = new FileReader();
    reader.onload = function () {
      const newProduct = {
        name: productName,
        image: reader.result,
        price: productPrice,
        quantity: productQuantity,
        colors: productColors,
      };

      products.push(newProduct);
      displayProducts(products);
      addProductForm.reset();
    };
    reader.readAsDataURL(productImage);
  });
});

document.addEventListener("DOMContentLoaded", () => {
  const logoutLink = document.getElementById("logout-link");
  const confirmPopup = document.getElementById("confirm-popup");
  const confirmLogout = document.getElementById("confirm-logout");
  const cancelLogout = document.getElementById("cancel-logout");

  // เมื่อคลิกที่ปุ่ม Logout ให้แสดง Popup
  logoutLink.addEventListener("click", (e) => {
    e.preventDefault(); // ป้องกันการกระทำเริ่มต้นของลิงก์
    confirmPopup.classList.remove("hidden"); // แสดง Popup
  });

  // เมื่อกดยืนยัน Logout ให้เปลี่ยนหน้าไปที่ login.html
  confirmLogout.addEventListener("click", () => {
    window.location.href = "register.html"; // ไปยังไฟล์ login.html
  });

  // เมื่อกดยกเลิก Popup ให้ซ่อน Popup
  cancelLogout.addEventListener("click", () => {
    confirmPopup.classList.add("hidden"); // ซ่อน Popup
  });
});