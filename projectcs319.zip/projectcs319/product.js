const productList = document.querySelector('.product-list');

function addProduct(name, price, rating, image) {
  const productCard = `
    <div class="product-card">
      <img src="${image}" alt="${name}">
      <h3>${name}</h3>
      <p class="price">$${price}</p>
      <p class="rating">${'⭐'.repeat(rating)} (${Math.floor(Math.random() * 200) + 1})</p>
    </div>
  `;
  productList.innerHTML += productCard;
}


document.addEventListener("DOMContentLoaded", () => {
  const logoutLink = document.getElementById("logout-link");
  const confirmPopup = document.getElementById("confirm-popup");
  const confirmLogout = document.getElementById("confirm-logout");
  const cancelLogout = document.getElementById("cancel-logout");

  // เมื่อคลิกที่ปุ่ม Logout ให้แสดง Popup
  logoutLink.addEventListener("click", (e) => {
    e.preventDefault(); // ป้องกันการกระทำเริ่มต้นของลิงก์
    confirmPopup.classList.remove("hidden"); // แสดง Popup
  });

  // เมื่อกดยืนยัน Logout ให้เปลี่ยนหน้าไปที่ login.html
  confirmLogout.addEventListener("click", () => {
    window.location.href = "register.html"; // ไปยังไฟล์ login.html
  });

  // เมื่อกดยกเลิก Popup ให้ซ่อน Popup
  cancelLogout.addEventListener("click", () => {
    confirmPopup.classList.add("hidden"); // ซ่อน Popup
  });
});