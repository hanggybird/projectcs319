document.addEventListener("DOMContentLoaded", function() {
	const loginForm = document.querySelector(".form-login");
	const signupForm = document.querySelector(".form-signup");

	// Handle login form submission
	loginForm.addEventListener("submit", function(event) {
		event.preventDefault(); // Prevent default form submission

		// Get the login credentials
		const email = document.querySelector("#login-email").value;
		const password = document.querySelector("#login-password").value;

		// Hardcoded login credentials (you would typically verify with a backend)
		if (email === "user@example.com" && password === "password123") {
			// Redirect to dashboard if login is successful
			window.location.href = "dashboard.html"; // The path to the dashboard page
		} else {
			alert("Invalid credentials. Please try again.");
		}
	});

	// Handle sign-up form submission
	signupForm.addEventListener("submit", function(event) {
		event.preventDefault(); // Prevent default form submission

		// Get the sign-up credentials
		const email = document.querySelector("#signup-email").value;
		const password = document.querySelector("#signup-password").value;
		const passwordConfirm = document.querySelector("#signup-password-confirm").value;

		// Simple validation to check password match
		if (password !== passwordConfirm) {
			alert("Passwords do not match. Please try again.");
			return;
		}

		// If the sign-up form is valid
		alert(`Welcome, ${email}! You have signed up successfully.`);
		// In a real-world scenario, you'd make a request to your backend to create a new user.

		// After sign-up, you could optionally redirect to the login form or a dashboard.
		// window.location.href = "dashboard.html"; // The path to the dashboard page
	});
});

// Handle switching between Login and Sign-up forms
const switchers = [...document.querySelectorAll('.switcher')];

switchers.forEach(item => {
	item.addEventListener('click', function() {
		switchers.forEach(item => item.parentElement.classList.remove('is-active'));
		this.parentElement.classList.add('is-active');
	});
});
