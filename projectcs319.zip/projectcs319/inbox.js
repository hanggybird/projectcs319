// Get DOM elements
const sendBtn = document.getElementById('sendBtn');
const messageInput = document.getElementById('messageInput');
const chatBox = document.querySelector('.chat-box');

// Event listener for sending a message
sendBtn.addEventListener('click', sendMessage);

// Function to send a message
function sendMessage() {
  const userMessage = messageInput.value.trim();

  if (userMessage) {
    // Create and append the user's message to the chat
    const userMessageElement = document.createElement('div');
    userMessageElement.classList.add('message', 'sent');
    userMessageElement.innerHTML = `<span class="sender">You:</span> ${userMessage}`;
    chatBox.appendChild(userMessageElement);

    // Scroll to the latest message
    chatBox.scrollTop = chatBox.scrollHeight;

    // Clear input field
    messageInput.value = '';

    // Simulate customer service response after a short delay
    setTimeout(() => {
      const botResponse = getBotResponse(userMessage);
      const botMessageElement = document.createElement('div');
      botMessageElement.classList.add('message', 'received');
      botMessageElement.innerHTML = `<span class="sender">Customer Support:</span> ${botResponse}`;
      chatBox.appendChild(botMessageElement);
      
      // Scroll to the latest message
      chatBox.scrollTop = chatBox.scrollHeight;
    }, 1000);
  }
}

// Function to simulate customer service response
function getBotResponse(userMessage) {
  // Basic simulation logic (can be more advanced)
  if (userMessage.toLowerCase().includes('order number')) {
    return 'Please provide your order number, and I will assist you with your request.';
  } else if (userMessage.toLowerCase().includes('help')) {
    return 'I\'m here to help. What do you need assistance with?';
  } else if (userMessage.toLowerCase().includes('shipping')) {
    return 'Your order has been shipped and should arrive soon. Would you like to track it?';
  } else {
    return 'I\'m sorry, I didn\'t understand that. Could you please provide more details?';
  }
}
document.addEventListener("DOMContentLoaded", () => {
  const logoutLink = document.getElementById("logout-link");
  const confirmPopup = document.getElementById("confirm-popup");
  const confirmLogout = document.getElementById("confirm-logout");
  const cancelLogout = document.getElementById("cancel-logout");

  // เมื่อคลิกที่ปุ่ม Logout ให้แสดง Popup
  logoutLink.addEventListener("click", (e) => {
    e.preventDefault(); // ป้องกันการกระทำเริ่มต้นของลิงก์
    confirmPopup.classList.remove("hidden"); // แสดง Popup
  });

  // เมื่อกดยืนยัน Logout ให้เปลี่ยนหน้าไปที่ login.html
  confirmLogout.addEventListener("click", () => {
    window.location.href = "register.html"; // ไปยังไฟล์ login.html
  });

  // เมื่อกดยกเลิก Popup ให้ซ่อน Popup
  cancelLogout.addEventListener("click", () => {
    confirmPopup.classList.add("hidden"); // ซ่อน Popup
  });
});
